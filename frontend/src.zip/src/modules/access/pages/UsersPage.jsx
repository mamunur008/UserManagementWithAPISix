import { useEffect, useMemo, useState } from "react";
import { userApi } from "../../../services/userApi.js";
import { CrudDrawerForm } from "../components/CrudDrawerForm.jsx";
import { CrudPageLayout } from "../components/CrudPageLayout.jsx";
import { CrudTableCard } from "../components/CrudTableCard.jsx";
import { CrudToolbar } from "../components/CrudToolbar.jsx";
import { EmptyState } from "../components/EmptyState.jsx";
import { StatusBadge } from "../components/StatusBadge.jsx";

// Replace these with your real API/service imports
// import { getUsers, createUser, updateUser } from "../services/users.service.js";

const initialForm = {
  name: "",
  email: "",
  role: "",
  status: "active",
};

export function UsersPage() {
  const [users, setUsers] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [form, setForm] = useState(initialForm);

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    try {
      setLoading(true);

      // Replace this mock data with your real service call

      const data1 = [
        {
          id: 1,
          name: "John Doe",
          email: "john@example.com",
          role: "Admin",
          status: "active",
        },
        {
          id: 2,
          name: "Jane Smith",
          email: "jane@example.com",
          role: "Editor",
          status: "inactive",
        },
      ];
      // const data = await getUsers();
      // setUsers(data);
      /* const result = await getUsers({
        page: 1,
        pageSize: 20,
        search: search,
      }); */
      const users = await userApi.list();
      setUsers(users);
      // setTotal(result.total);
    } finally {
      setLoading(false);
    }
  }

  function resetForm() {
    setEditingUser(null);
    setForm(initialForm);
  }

  function openCreateDrawer() {
    resetForm();
    setDrawerOpen(true);
  }

  function openEditDrawer(user) {
    setEditingUser(user);
    setForm({
      name: user.name || "",
      email: user.email || "",
      role: user.role || "",
      status: user.status || "active",
    });
    setDrawerOpen(true);
  }

  function closeDrawer() {
    setDrawerOpen(false);
  }

  async function handleSubmit() {
    try {
      setSaving(true);

      const payload = {
        name: form.name.trim(),
        email: form.email.trim(),
        role: form.role.trim(),
        status: form.status,
      };

      if (!payload.name || !payload.email || !payload.role) {
        return;
      }

      if (editingUser) {
        // await updateUser(editingUser.id, payload);

        setUsers((prev) =>
          prev.map((user) =>
            user.id === editingUser.id ? { ...user, ...payload } : user,
          ),
        );
      } else {
        // await createUser(payload);

        const nextUser = {
          id: Date.now(),
          ...payload,
        };

        setUsers((prev) => [nextUser, ...prev]);
      }

      setDrawerOpen(false);
      resetForm();

      // If using a real API and want fresh data:
      // await loadUsers();
    } finally {
      setSaving(false);
    }
  }

  const filteredUsers = useMemo(() => {
    const q = search.toLowerCase().trim();

    if (!q) return users;

    return users.filter((user) =>
      [user.name, user.email, user.role, user.status]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(q)),
    );
  }, [users, search]);

  return (
    <CrudPageLayout
      title="Users"
      description="Manage user accounts, roles, and access."
      actions={
        <button
          type="button"
          onClick={openCreateDrawer}
          className="inline-flex items-center rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
        >
          Add User
        </button>
      }
    >
      <CrudToolbar
        filters={
          <div className="flex flex-wrap items-end gap-3">
            <div className="min-w-0">
              <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-500">
                Search
              </label>
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search users by name, email, role..."
                className="w-72 rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-200"
              />
            </div>
          </div>
        }
        actions={
          <button
            type="button"
            onClick={openCreateDrawer}
            className="inline-flex items-center rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
          >
            Add User
          </button>
        }
      />

      {loading ? (
        <CrudTableCard title="Users">
          <div className="p-6 text-sm text-slate-500">Loading users...</div>
        </CrudTableCard>
      ) : filteredUsers.length === 0 ? (
        <EmptyState
          title="No users found"
          description="Try a different search or create a new user."
          actionLabel="Add User"
          onAction={openCreateDrawer}
        />
      ) : (
        <CrudTableCard
          title="Users"
          subtitle={`${filteredUsers.length} result(s)`}
        >
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-slate-500">
                  <th className="px-4 py-3 font-medium">Name</th>
                  <th className="px-4 py-3 font-medium">Email</th>
                  <th className="px-4 py-3 font-medium">Role</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>

              <tbody>
                {filteredUsers.map((user) => (
                  <tr
                    key={user.id}
                    className="border-b border-slate-100 last:border-b-0"
                  >
                    <td className="px-4 py-3 font-medium text-slate-900">
                      {user.name}
                    </td>
                    <td className="px-4 py-3 text-slate-600">{user.email}</td>
                    <td className="px-4 py-3 text-slate-700">{user.role}</td>
                    <td className="px-4 py-3">
                      <StatusBadge status={user.status} />
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => openEditDrawer(user)}
                        className="rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 transition hover:bg-slate-50"
                      >
                        Edit
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CrudTableCard>
      )}

      <CrudDrawerForm
        modelValue={drawerOpen}
        onUpdateModelValue={setDrawerOpen}
        title={editingUser ? "Edit User" : "Create User"}
        width="540px"
        loading={saving}
        saveText={editingUser ? "Save Changes" : "Create User"}
        cancelText="Cancel"
        onSubmit={handleSubmit}
        onCancel={closeDrawer}
      >
        <div className="space-y-5">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              {editingUser ? "Update user details" : "Add a new user"}
            </h3>
            <p className="mt-1 text-sm text-slate-500">
              {editingUser
                ? "Update the selected user details and access information."
                : "Create a new user and assign their access role."}
            </p>
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">
              Name
            </label>
            <input
              type="text"
              value={form.name}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, name: e.target.value }))
              }
              className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-200"
              placeholder="Enter full name"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">
              Email
            </label>
            <input
              type="email"
              value={form.email}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, email: e.target.value }))
              }
              className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-200"
              placeholder="Enter email"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">
              Role
            </label>
            <input
              type="text"
              value={form.role}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, role: e.target.value }))
              }
              className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-200"
              placeholder="Enter role"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">
              Status
            </label>
            <select
              value={form.status}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, status: e.target.value }))
              }
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-200"
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </CrudDrawerForm>
    </CrudPageLayout>
  );
}

export default UsersPage;
