import { useEffect, useMemo, useState } from "react";
import { rolesConfig } from "../configs/roles.config";

const seedRoles = [
  { id: 1, name: "Admin", description: "Full system access", status: "active" },
  {
    id: 2,
    name: "Manager",
    description: "Operational management access",
    status: "active",
  },
  {
    id: 3,
    name: "Viewer",
    description: "Read-only access",
    status: "inactive",
  },
];

function StatusBadge({ status }) {
  const isActive = status === "active";

  return (
    <span
      className={[
        "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium capitalize",
        isActive
          ? "bg-emerald-100 text-emerald-700"
          : "bg-slate-100 text-slate-600",
      ].join(" ")}
    >
      {status}
    </span>
  );
}

function Drawer({
  open,
  title,
  width = 480,
  loading,
  saveText,
  onClose,
  onSubmit,
  children,
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40">
      <div
        className="flex h-full w-full max-w-2xl flex-col bg-white shadow-2xl"
        style={{ width }}
      >
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="rounded-md px-3 py-1.5 text-sm text-slate-600 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Close
          </button>
        </div>

        <form onSubmit={onSubmit} className="flex min-h-0 flex-1 flex-col">
          <div className="flex-1 overflow-y-auto px-6 py-5">{children}</div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-200 px-6 py-4">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? "Saving..." : saveText}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export function RolesPage() {
  const defaultForm = rolesConfig?.defaultForm ?? {
    id: null,
    name: "",
    description: "",
    status: "active",
  };

  const statuses = rolesConfig?.filters?.statuses ?? ["active", "inactive"];

  const [allRows, setAllRows] = useState(seedRoles);
  const [filters, setFilters] = useState({ keyword: "", status: "" });
  const [appliedFilters, setAppliedFilters] = useState({
    keyword: "",
    status: "",
  });

  const [page, setPage] = useState(1);
  const [pageSize] = useState(5);

  const [drawerVisible, setDrawerVisible] = useState(false);
  const [drawerLoading, setDrawerLoading] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const [form, setForm] = useState({ ...defaultForm });

  const [notice, setNotice] = useState("");

  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(""), 2500);
    return () => clearTimeout(timer);
  }, [notice]);

  const filteredRows = useMemo(() => {
    const keyword = appliedFilters.keyword.trim().toLowerCase();
    const status = appliedFilters.status;

    return allRows.filter((item) => {
      const matchesKeyword =
        !keyword ||
        item.name.toLowerCase().includes(keyword) ||
        item.description.toLowerCase().includes(keyword);

      const matchesStatus = !status || item.status === status;

      return matchesKeyword && matchesStatus;
    });
  }, [allRows, appliedFilters]);

  const total = filteredRows.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  useEffect(() => {
    setPage(1);
  }, [appliedFilters]);

  useEffect(() => {
    if (page > totalPages) {
      setPage(totalPages);
    }
  }, [page, totalPages]);

  const pagedRows = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredRows.slice(start, start + pageSize);
  }, [filteredRows, page, pageSize]);

  const openCreate = () => {
    setEditingRecord(null);
    setForm({ ...defaultForm });
    setDrawerVisible(true);
  };

  const openEdit = (row) => {
    setEditingRecord(row);
    setForm({ ...defaultForm, ...row });
    setDrawerVisible(true);
  };

  const closeDrawer = () => {
    setDrawerVisible(false);
    setEditingRecord(null);
    setForm({ ...defaultForm });
  };

  const runSearch = () => {
    setAppliedFilters({
      keyword: filters.keyword,
      status: filters.status,
    });
  };

  const resetSearch = () => {
    const next = { keyword: "", status: "" };
    setFilters(next);
    setAppliedFilters(next);
  };

  const upsertRow = (payload) => {
    setAllRows((current) => {
      const exists = current.some((item) => item.id === payload.id);
      if (exists) {
        return current.map((item) => (item.id === payload.id ? payload : item));
      }
      return [payload, ...current];
    });
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    setDrawerLoading(true);

    try {
      const payload = {
        id: form.id || Date.now(),
        name: form.name?.trim() || "",
        description: form.description?.trim() || "",
        status: form.status || "active",
      };

      upsertRow(payload);
      closeDrawer();
      setNotice(
        editingRecord
          ? "Role updated successfully"
          : "Role created successfully",
      );
    } finally {
      setDrawerLoading(false);
    }
  };

  const onDelete = (row) => {
    const confirmed = window.confirm(`Delete role "${row.name}"?`);
    if (!confirmed) return;

    setAllRows((current) => current.filter((item) => item.id !== row.id));
    setNotice("Role deleted successfully");
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col gap-4 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200 md:flex-row md:items-start md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            {rolesConfig?.title ?? "Roles"}
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            {rolesConfig?.description ?? "Manage role definitions and access."}
          </p>
        </div>

        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center justify-center rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
        >
          Add Role
        </button>
      </div>

      {notice ? (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
          {notice}
        </div>
      ) : null}

      <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="grid flex-1 gap-4 md:grid-cols-2">
            <div className="w-full">
              <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-500">
                Search
              </label>
              <input
                type="text"
                value={filters.keyword}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, keyword: e.target.value }))
                }
                placeholder="Role name or description"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none ring-0 placeholder:text-slate-400 focus:border-slate-400"
              />
            </div>

            <div className="w-full">
              <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-500">
                Status
              </label>
              <select
                value={filters.status}
                onChange={(e) =>
                  setFilters((prev) => ({ ...prev, status: e.target.value }))
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-slate-400"
              >
                <option value="">All statuses</option>
                {statuses.map((item) => (
                  <option key={item} value={item}>
                    {item.charAt(0).toUpperCase() + item.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={resetSearch}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Reset
            </button>
            <button
              type="button"
              onClick={runSearch}
              className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
            >
              Search
            </button>
          </div>
        </div>
      </div>

      <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
        <div className="border-b border-slate-200 px-6 py-4">
          <h2 className="text-lg font-semibold text-slate-900">
            {rolesConfig?.tableTitle ?? "Roles"}
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            {rolesConfig?.tableDescription ?? "Browse and manage system roles."}
          </p>
        </div>

        {filteredRows.length === 0 ? (
          <div className="px-6 py-16 text-center">
            <h3 className="text-base font-semibold text-slate-900">
              No roles found
            </h3>
            <p className="mt-2 text-sm text-slate-500">
              There are no roles matching the current search criteria.
            </p>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Role
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Description
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Status
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Actions
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-200 bg-white">
                  {pagedRows.map((row) => (
                    <tr key={row.id}>
                      <td className="px-6 py-4 text-sm font-medium text-slate-900">
                        {row.name}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {row.description}
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <StatusBadge status={row.status} />
                      </td>
                      <td className="px-6 py-4 text-right text-sm">
                        <div className="flex items-center justify-end gap-3">
                          <button
                            type="button"
                            onClick={() => openEdit(row)}
                            className="font-medium text-blue-600 hover:text-blue-700"
                          >
                            Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => onDelete(row)}
                            className="font-medium text-red-600 hover:text-red-700"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between border-t border-slate-200 px-6 py-4">
              <p className="text-sm text-slate-500">
                Showing {(page - 1) * pageSize + 1}-
                {Math.min(page * pageSize, total)} of {total}
              </p>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setPage((prev) => Math.max(1, prev - 1))}
                  disabled={page === 1}
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Prev
                </button>

                {Array.from(
                  { length: totalPages },
                  (_, index) => index + 1,
                ).map((pageNumber) => (
                  <button
                    key={pageNumber}
                    type="button"
                    onClick={() => setPage(pageNumber)}
                    className={[
                      "rounded-lg px-3 py-2 text-sm",
                      pageNumber === page
                        ? "bg-slate-900 text-white"
                        : "border border-slate-300 text-slate-700 hover:bg-slate-50",
                    ].join(" ")}
                  >
                    {pageNumber}
                  </button>
                ))}

                <button
                  type="button"
                  onClick={() =>
                    setPage((prev) => Math.min(totalPages, prev + 1))
                  }
                  disabled={page === totalPages}
                  className="rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Next
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      <Drawer
        open={drawerVisible}
        title={editingRecord ? "Edit Role" : "Create Role"}
        width={rolesConfig?.drawerWidth ?? 480}
        loading={drawerLoading}
        saveText={editingRecord ? "Update role" : "Create role"}
        onClose={closeDrawer}
        onSubmit={onSubmit}
      >
        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Role Details
            </h3>
            <p className="mt-1 text-sm text-slate-500">
              Define the role and maintain a concise operational description.
            </p>
          </div>

          <div className="space-y-5">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">
                Role Name
              </label>
              <input
                type="text"
                value={form.name || ""}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, name: e.target.value }))
                }
                placeholder="Enter role name"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-slate-400"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">
                Description
              </label>
              <textarea
                rows={4}
                value={form.description || ""}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
                placeholder="Describe this role"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-slate-400"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">
                Status
              </label>
              <select
                value={form.status || ""}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, status: e.target.value }))
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none focus:border-slate-400"
              >
                {statuses.map((item) => (
                  <option key={item} value={item}>
                    {item.charAt(0).toUpperCase() + item.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </Drawer>
    </div>
  );
}
export default RolesPage;
