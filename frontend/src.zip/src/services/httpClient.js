import axios from 'axios';

let authSnapshot = null;

export function setAuthSnapshot(value) {
  authSnapshot = value;
}

export const http = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:9080/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
});

http.interceptors.request.use((config) => {
  const auth = authSnapshot || JSON.parse(localStorage.getItem('um.auth') || 'null');
  if (auth?.accessToken) config.headers.Authorization = `Bearer ${auth.accessToken}`;
  if (auth?.sessionId) config.headers['X-Session-Id'] = auth.sessionId;
  return config;
});

http.interceptors.response.use(
  (response) => response,
  (error) => {
    const body = error.response?.data;
    const message = body?.message || body?.title || body?.error || error.message || 'Unexpected API error';
    return Promise.reject({ ...error, friendlyMessage: message, status: error.response?.status });
  }
);

export function unwrap(response) {
  return response.data;
}
